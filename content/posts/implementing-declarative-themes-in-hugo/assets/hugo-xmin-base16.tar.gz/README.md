# The Xmin theme

The [Xmin theme](https://github.com/yihui/hugo-xmin/) forked by [yours truly](http://foo-dogsquared.github.io/).
With [Base16](https://github.com/chriskempson/base16) themes included.
Hoorah!




## About the project

This is really just a proof-of-concept for implementing custom themes with Base16.
I really like the result of it so I'll let this into the public.

If you want to make this as your own, feel free to do so.




## Prerequisites

- Hugo v0.74.0 and above.
- Go runtime (preferably v1.15 and above).
- Git.




## Getting started

Just `hugo serve` it. :)

